This is the Web App Developed for the Conferece Event held in NBN sinhgad College of Engineering, Solapur 

1. To Run this App First install the 
Node js 

2. Next install the Dependecies 
 npm install express body-parser ejs path
 
 run byu : node app.js
